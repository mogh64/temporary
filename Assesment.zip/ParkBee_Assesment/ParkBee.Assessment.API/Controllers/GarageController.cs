﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Common;
using System.Threading.Tasks;

namespace ParkBee.Assessment.API.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class GarageController : ControllerBase
    {
        private readonly IGarageService garageService;
        private readonly CurrentUser currentUser;

        public GarageController(IGarageService garageService,
                                CurrentUser currentUser)
        {
            this.garageService = garageService;
            this.currentUser = currentUser;
        }

        [HttpGet]
        public async Task<IActionResult> GetDetail()
        {
            var garageDetailInfo = await garageService.GetGarageDetail(currentUser.GarageId);
            return Ok(garageDetailInfo);
        }

        [HttpGet("refresh")]
        public async Task<IActionResult> GetDoorsRefreshData()
        {
            var garageDoorsLatestState = await garageService.GetDoorsLatestState(currentUser.GarageId);
            return Ok(garageDoorsLatestState);
        }

        [HttpGet("refresh/{doorNo}")]
        public async Task<IActionResult> GetSpecificDoorRefreshData(int doorNo)
        {
            var garageSpecificDoorLatestState = await garageService.GetDoorLatestState(currentUser.GarageId, doorNo);
            return Ok(garageSpecificDoorLatestState);
        }
    }
}
