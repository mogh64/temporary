﻿using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.API.Providers;
using ParkBee.Assessment.Application.FactoryServices;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Infrastructure.Persistence.Repositories;
using ParkBee.Assessment.Infrastructure.Services;

namespace ParkBee.Assessment.API.Extensions
{
    public static class DependencyManagerExtensions
    {
        public static void AddDependencies(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            AddCurrentUser(services);
            AddServices(services);
            AddRepositories(services);
        }

        private static void AddRepositories(IServiceCollection services)
        {
            services.AddScoped<IGarageRepository, GarageRepository>();
            services.AddScoped<IUserRepository, UserRepository>();            
            services.AddScoped<IDoorStatusHistoryRepository, DoorStatusHistoryRepository>();           
        }

        private static void AddServices(IServiceCollection services)
        {
            services.AddScoped<IGarageService, GarageService>();
            services.AddScoped<IPingService, PingService>();
            services.AddScoped<IPingService, FakePingService>();
            services.AddScoped<IPingServiceFactory, PingServiceFactory>();
            services.AddScoped<IDoorStatusService, DoorStatusService>();
            services.AddScoped<ICacheService, CacheService>();
        }

        private static void AddCurrentUser(IServiceCollection services)
        {
            services.AddScoped(provider =>
            {
                return CurrentUserProvider.Read(provider);
            });
        }


    }
}
