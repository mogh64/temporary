﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.Domain.Common;
using ParkBee.Assessment.Domain.Constants;
using System;
using System.Linq;
using System.Security.Claims;

namespace ParkBee.Assessment.API.Providers
{
    public class CurrentUserProvider
    {
        public static CurrentUser Read(IServiceProvider provider)
        {
            var claims = provider.GetService<IHttpContextAccessor>().HttpContext.User.Claims;

            var userNameClaim = claims.SingleOrDefault(c => c.Type == ClaimTypes.Name);
            string userName = "";
            if (userNameClaim != null)
            {
                userName = userNameClaim.Value;
            }

            var userGarageClaim = claims.SingleOrDefault(c => c.Type == ParkBeeClaimTypes.GarageId);
            string garageId = "";
            if (userGarageClaim != null)
            {
                garageId = userGarageClaim.Value;
            }

            var userEmailClaim = claims.SingleOrDefault(c => c.Type == ClaimTypes.Email);
            string userEmail = "";
            if (userEmailClaim != null)
            {
                userEmail = userEmailClaim.Value;
            }

            return new CurrentUser()
            {
                UserEmail = userEmail,
                GarageId = int.Parse(garageId),
                UserName = userName
            };
        }
    }
}
