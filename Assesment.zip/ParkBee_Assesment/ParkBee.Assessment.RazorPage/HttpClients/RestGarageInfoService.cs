﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ParkBee.Assessment.RazorPage.Base;
using ParkBee.Assessment.RazorPage.Models;
using RestSharp;
using System.Threading.Tasks;

namespace ParkBee.Assessment.RazorPage.HttpClients
{
    public class RestGarageInfoService
    {
        private readonly string garageServiceUrl;
        public RestGarageInfoService(IOptions<UrlsOptions> urlSettingsOption)
        {
            garageServiceUrl = urlSettingsOption.Value.GarageService;
        }

        public async Task<GarageResultDto> GetGarageDetailInfo()
        {
            var client = new RestClient(garageServiceUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", GetAuthToken());
            IRestResponse response = await client.ExecuteAsync(request);
            var garageData = JsonConvert.DeserializeObject<GarageResultDto>(response.Content);
            return garageData;
        }
        private string GetAuthToken()
        {
            return $"Bearer {StaticStore.Token}";
        }
    }
}
