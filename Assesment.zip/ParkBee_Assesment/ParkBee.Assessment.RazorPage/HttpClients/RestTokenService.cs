﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ParkBee.Assessment.RazorPage.Base;
using RestSharp;
using System;
using System.Threading.Tasks;

namespace ParkBee.Assessment.RazorPage.HttpClients
{
    public class RestTokenService
    {
        private readonly string tokenServiceUrl;
        public RestTokenService(IOptions<UrlsOptions> urlSettingsOption)
        {
            this.tokenServiceUrl = urlSettingsOption.Value.TokenService;
        }
        public async Task<string> GetToken(string username, string password)
        {
            var client = new RestClient(tokenServiceUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            var jsonModel = JsonConvert.SerializeObject(new { username = username, password = password });
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", jsonModel, ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            var tokenData = JsonConvert.DeserializeObject<TokenData>(response.Content);
            return tokenData.Token;
        }
    }
    public class TokenData
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
    }
}
