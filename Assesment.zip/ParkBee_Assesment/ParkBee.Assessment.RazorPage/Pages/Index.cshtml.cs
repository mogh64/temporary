﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ParkBee.Assessment.RazorPage.Base;
using ParkBee.Assessment.RazorPage.HttpClients;
using ParkBee.Assessment.RazorPage.Models;
using System.Threading.Tasks;

namespace ParkBee.Assessment.RazorPage.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IOptions<UrlsOptions> urlsSettings;
        private readonly RestGarageInfoService restGarageInfoService;

        public IndexModel(ILogger<IndexModel> logger,
                          IOptions<UrlsOptions> urlsSettings,
                          RestGarageInfoService restGarageInfoService)
        {
            _logger = logger;
            this.urlsSettings = urlsSettings;
            this.restGarageInfoService = restGarageInfoService;
        }
        [BindProperty]
        public GarageResultDto GarageResultDto { get; set; }

        public async Task OnGetAsync()
        {
            GarageResultDto = await restGarageInfoService.GetGarageDetailInfo();
            ViewData["token"] = StaticStore.Token;
            ViewData["garageServiceUrl"] = urlsSettings.Value.GarageService;
        }
    }
}
