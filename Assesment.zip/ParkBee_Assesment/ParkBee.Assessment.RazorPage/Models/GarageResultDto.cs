﻿namespace ParkBee.Assessment.RazorPage.Models
{
    public class GarageResultDto
    {
        public string OwnerName { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }
        public DoorDto[] Doors { get; set; }
        public bool Status
        {
            get; set;
        }
        public string StatusDescription
        {
            get;set;
        }

    }
}
