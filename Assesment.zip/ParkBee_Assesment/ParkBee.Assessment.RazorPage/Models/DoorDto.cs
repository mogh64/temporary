﻿namespace ParkBee.Assessment.RazorPage.Models
{
    public class DoorDto
    {
        public string Name { get; set; }
        public int DoorNo { get; set; }
        public bool Status { get; set; }
        public string IPAddress { get; set; }
        public string StatusDescription
        {
            get;set;            
        }
        public string StatusIcon
        {
            get
            {
                return StatusDescription + ".png";
            }
        }
    }
}
