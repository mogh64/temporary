﻿namespace ParkBee.Assessment.RazorPage.Base
{
    public class UrlsOptions
    {
        public const string Name = "Urls";
        public string TokenService { get; set; }
        public string GarageService { get; set; }
    }
}
