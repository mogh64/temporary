﻿namespace ParkBee.Assessment.RazorPage.Base
{
    public class StaticStore
    {
        public static string Token = "";
    }
}
