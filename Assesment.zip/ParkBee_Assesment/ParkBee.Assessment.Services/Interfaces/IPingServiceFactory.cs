﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Application.Interfaces
{
    public interface IPingServiceFactory
    {
        IPingService GetService();
    }
}
