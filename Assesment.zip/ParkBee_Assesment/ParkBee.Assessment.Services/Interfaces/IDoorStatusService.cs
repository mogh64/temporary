﻿using ParkBee.Assessment.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Application.Interfaces
{
    public interface IDoorStatusService
    {
        Task<bool> CheckAndSet(Door door);
    }
}
