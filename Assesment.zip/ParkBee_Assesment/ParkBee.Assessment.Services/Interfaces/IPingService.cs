﻿using System.Threading.Tasks;

namespace ParkBee.Assessment.Application.Interfaces
{
    public interface IPingService
    {
        Task<bool> CheckIsAvailable(string ipAddress);
        string Type { get; }
    }
}
