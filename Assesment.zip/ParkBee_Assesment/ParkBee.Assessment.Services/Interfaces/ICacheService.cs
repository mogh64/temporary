﻿using ParkBee.Assessment.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Application.Interfaces
{
    public interface ICacheService
    {
        void Set<T>(string key, T value);
        CacheData<T> Get<T>(string key); 
    }
}
