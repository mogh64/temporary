﻿using ParkBee.Assessment.Application.Dtos;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Application.Interfaces
{
    public interface IGarageService
    {
        Task<GarageOutputDto> GetGarageDetail(int garageId);
        Task<GarageDoorsOutputDto> GetDoorsLatestState(int garageId);
        Task<DoorOutputDto> GetDoorLatestState(int garageId, int doorNo);
    }
}
