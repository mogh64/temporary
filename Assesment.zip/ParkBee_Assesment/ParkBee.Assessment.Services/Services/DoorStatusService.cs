﻿using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Application.Services
{
    public class DoorStatusService : IDoorStatusService
    {
        private readonly IPingService pingService;
        private readonly ICacheService cacheService;
        private readonly IDoorStatusHistoryRepository statusHistoryRepository;        

        public DoorStatusService(IPingServiceFactory pingServiceFactory,
                                 ICacheService cacheService,                                
                                 IDoorStatusHistoryRepository statusHistoryWriteRepository)
        {
            pingService = pingServiceFactory.GetService();
            this.cacheService = cacheService;            
            this.statusHistoryRepository = statusHistoryWriteRepository;
        }

        public async Task<bool> CheckAndSet(Door door)
        {
            var currntStatus = await pingService.CheckIsAvailable(door.IPAddress);
            var latestRegisteredDoorStatus = await GetLatestRegisteredDoorStatusHistory(door, currntStatus);

            if (latestRegisteredDoorStatus != currntStatus)
            {
                await RegisterStatusHistory(door, currntStatus);
            }

            return currntStatus;
        }

        private Task RegisterStatusHistory(Door door, bool currntStatus)
        {
            var newDoorStatusHistory = new DoorStatusHistory(door.GarageId, door.DoorNo, currntStatus);
            return statusHistoryRepository.AppendStatusHistory(newDoorStatusHistory);
        }
        private async Task<bool> GetLatestRegisteredDoorStatusHistory(Door door, bool currntStatus)
        {
            var cacheValue = cacheService.Get<bool>(GetCahceKey(door.Id));

            bool latestRegisteredDoorStatus;
            if (!cacheValue.HasValue)
            {
                var doorLatestDbStatus = await statusHistoryRepository.GetLatestStatus(door.GarageId, door.DoorNo);
                if (doorLatestDbStatus == null)
                {
                    await RegisterStatusHistory(door, currntStatus);
                    cacheService.Set(GetCahceKey(door.Id), currntStatus);
                    latestRegisteredDoorStatus = currntStatus;
                }
                else
                {
                    cacheService.Set(GetCahceKey(door.Id), doorLatestDbStatus);
                    latestRegisteredDoorStatus = doorLatestDbStatus.Value;
                }
            }
            else
            {
                latestRegisteredDoorStatus = cacheValue.Data;
            }
            return latestRegisteredDoorStatus;
        }

        private string GetCahceKey(int doorId)
        {
            return $"door-{doorId}";
        }
    }
}
