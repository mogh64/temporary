﻿using ParkBee.Assessment.Application.Dtos;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Domain.Exceptions;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Application.Services
{
    public class GarageService : IGarageService
    {
        private readonly IDoorStatusService doorStatusService;
        private readonly IGarageRepository garageRepository;

        public GarageService(IDoorStatusService doorStatusService,
                             IGarageRepository garageRepository)
        {
            this.doorStatusService = doorStatusService;
            this.garageRepository = garageRepository;
        }

        public async Task<DoorOutputDto> GetDoorLatestState(int garageId, int doorNo)
        {
            var garageDoor = await garageRepository.GetDoor(garageId, doorNo);
            if (garageDoor == null)
            {
                throw new NotFoundException();
            }

            return await CreateDoorOutputDto(garageDoor);
        }

        public async Task<GarageDoorsOutputDto> GetDoorsLatestState(int garageId)
        {
            var garageDoors = await garageRepository.GetDoors(garageId);
            var doorOutputDtos = await GetDoorOutputDto(garageDoors);

            return new GarageDoorsOutputDto() { Doors = doorOutputDtos };
        }

        public async Task<GarageOutputDto> GetGarageDetail(int garageId)
        {
            var garageByDoors = await garageRepository.GetByNavigations(garageId);
            if (garageByDoors == null)
            {
                throw new NotFoundException();
            }

            var doorOutputDtos = await GetDoorOutputDto(garageByDoors.Doors);

            return new GarageOutputDto()
            {
                OwnerName = garageByDoors.Owner.UserName,
                Address = garageByDoors.Address,
                Name = garageByDoors.Name,
                Doors = doorOutputDtos
            };
        }

        private async Task<DoorOutputDto[]> GetDoorOutputDto(IList<Door> garageDoors)
        {
            if (garageDoors == null || garageDoors.Count == 0)
            {
                return new DoorOutputDto[] { };
            }

            DoorOutputDto[] doorOutputDtos = new DoorOutputDto[garageDoors.Count];

            for (int i = 0; i < garageDoors.Count; i++)
            {                
                doorOutputDtos[i] = await CreateDoorOutputDto(garageDoors[i]);
            }

            return doorOutputDtos;
        }

        private async Task<DoorOutputDto> CreateDoorOutputDto(Door door)
        {
            var doorIsAvailable = await doorStatusService.CheckAndSet(door);

            return new DoorOutputDto()
            {
                Name = door.Name,
                Status = doorIsAvailable,
                DoorNo = door.DoorNo,
                IPAddress = door.IPAddress
            };
        }
    }
}
