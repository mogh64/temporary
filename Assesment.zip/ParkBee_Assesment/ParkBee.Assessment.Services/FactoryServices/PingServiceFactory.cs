﻿using Microsoft.Extensions.Options;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.OptionSettings;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ParkBee.Assessment.Application.FactoryServices
{
    public class PingServiceFactory : IPingServiceFactory
    {
        IPingService pingService;
        public PingServiceFactory(IOptions<SettingsOptions> settingsOptions,
                                  IEnumerable<IPingService> pingServices)
        {
            pingService = settingsOptions.Value.UseFakePing
                ? pingServices.FirstOrDefault(x => x.Type == "fake")
                : pingServices.FirstOrDefault(x => x.Type == "real");
        }
        public IPingService GetService()
        {
            return pingService;
        }
    }
}
