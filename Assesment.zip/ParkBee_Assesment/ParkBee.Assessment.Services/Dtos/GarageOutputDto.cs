﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ParkBee.Assessment.Application.Dtos
{
    public class GarageOutputDto
    {
        public string OwnerName { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }
        public IList<DoorOutputDto> Doors { get; set; }
        public bool Status
        {
            get
            {
                if (Doors != null && Doors.Count > 0)
                {
                    return Doors.Any(x => x.Status == true);
                }
                return false;
            }
        }
        public string StatusDescription
        {
            get
            {
                return Status ? "Online" : "Offline";
            }
        }
    }
}
