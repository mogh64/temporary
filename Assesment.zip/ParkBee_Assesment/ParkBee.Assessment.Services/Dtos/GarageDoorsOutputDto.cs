﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ParkBee.Assessment.Application.Dtos
{
    public class GarageDoorsOutputDto
    {
        public IList<DoorOutputDto> Doors { get; set; }
        public bool Status
        {
            get
            {
                if (Doors != null && Doors.Count > 0)
                {
                    return Doors.Any(x => x.Status == true);
                }
                return false;
            }
        }
        public string StatusDescription
        {
            get
            {
                return Status ? "Online" : "Offline";
            }
        }
    }
}
