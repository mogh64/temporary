﻿namespace ParkBee.Assessment.Application.Dtos
{
    public class DoorOutputDto
    {
        public string Name { get; set; }
        public int DoorNo { get; set; }
        public bool Status { get; set; }
        public string IPAddress { get; set; }
        public string StatusDescription
        {
            get
            {
                return Status ? "Online" : "Offline";
            }
        }
    }
}
