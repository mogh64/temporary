﻿using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ParkBee.Assessment.Infrastructure.Persistence.Repositories
{
    public class GarageRepository : IGarageRepository
    {
        private readonly ApplicationDbContext applicationDbContext;

        public GarageRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public Task<Garage> GetByNavigations(int garageId)
        {
           return applicationDbContext.Garages                                
                                .Where(x => x.Id == garageId)
                                .Include(x=>x.Doors)
                                .Include(x=>x.Owner)
                                .SingleOrDefaultAsync();                                
        }

        public Task<Door> GetDoor(int garageId, int doorNo)
        {
            return applicationDbContext.Doors
                                .Where(x => x.DoorNo == doorNo && x.GarageId==garageId)                                
                                .SingleOrDefaultAsync();
        }

        public Task<List<Door>> GetDoors(int garageId)
        {
            return applicationDbContext.Doors
                                .Where(x => x.GarageId== garageId)                                
                                .ToListAsync();                                
        }
    }
}
