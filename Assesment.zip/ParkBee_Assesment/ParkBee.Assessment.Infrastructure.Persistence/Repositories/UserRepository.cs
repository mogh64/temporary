﻿using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ParkBee.Assessment.Domain.Exceptions;

namespace ParkBee.Assessment.Infrastructure.Persistence.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext applicationDbContext;

        public UserRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public async Task<User> Login(string username, string password)
        {            
            var user = await applicationDbContext.Users.SingleOrDefaultAsync(x => x.UserName == username);
            if (user == null || !user.Password.Equals(password))
            {
                throw new AuthenticationFailedException();
            }
            return user;
        }
    }
}
