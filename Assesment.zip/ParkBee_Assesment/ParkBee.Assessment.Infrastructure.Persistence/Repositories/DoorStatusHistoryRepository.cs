﻿using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ParkBee.Assessment.Infrastructure.Persistence.Repositories
{
    public class DoorStatusHistoryRepository : IDoorStatusHistoryRepository
    {
        private readonly ApplicationDbContext dbContext;

        public DoorStatusHistoryRepository(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        

        public Task AppendStatusHistory(DoorStatusHistory doorStatusHistory)
        {
            dbContext.Add(doorStatusHistory);
            return dbContext.SaveChangesAsync();
        }

        public async Task<bool?> GetLatestStatus(int garageId, int doorNo)
        {
            var doorLatestStatusHistory = await dbContext.DoorStatusHistories.LastOrDefaultAsync(x => x.GarageId == garageId && x.DoorNo == doorNo);
            return doorLatestStatusHistory?.OnlineStatus;
        }
    }
}
