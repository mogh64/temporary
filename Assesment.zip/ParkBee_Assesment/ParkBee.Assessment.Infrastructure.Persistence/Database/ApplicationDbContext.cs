﻿using Microsoft.EntityFrameworkCore;
using ParkBee.Assessment.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Infrastructure.Persistence.Database
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Garage>()
                        .HasOne(x => x.Owner)
                        .WithOne(x => x.Garage)
                        .HasForeignKey<Garage>(x=>x.OwnerId);

          
        }
        
        public DbSet<Garage> Garages { get; set; }
        public DbSet<Door> Doors { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<DoorStatusHistory> DoorStatusHistories { get; set; }
    }
}
