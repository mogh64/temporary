﻿using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.UnitTest.FakeServices
{
    public class FakeCache : ICacheService
    {
        static Dictionary<string, object> dic = new Dictionary<string, object>();
        public CacheData<T> Get<T>(string key)
        {
            if (!dic.ContainsKey(key))
            {
                return new CacheData<T>() { Data = default(T), HasValue = false };
            }
            T obj = (T)dic[key];
            return new CacheData<T>() { Data = obj, HasValue = true };
        }

        public void Set<T>(string key, T value)
        {
            if (!dic.ContainsKey(key))
            {
                dic.Remove(key);
            }
            dic[key] = value;
        }
    }
}
