﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using ParkBee.Assessment.UnitTest.Base;
using Shouldly;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ParkBee.Assessment.UnitTest.Services.DoorStatusServices
{
    public class CheckAndSetTest : TestBase
    {
        IDoorStatusService doorStatusService;
        IDoorStatusHistoryRepository doorStatusHistoryRepository;        
        public CheckAndSetTest()
        {
            var pingServiceFactory = ServiceProvider.GetService<IPingServiceFactory>();
            var cacheService = ServiceProvider.GetService<ICacheService>();
            doorStatusHistoryRepository = ServiceProvider.GetService<IDoorStatusHistoryRepository>();
            doorStatusService = new DoorStatusService(pingServiceFactory, cacheService, doorStatusHistoryRepository);
            
        }
        [Fact]
        public async Task Should_Register_Status_History()
        {            
            var dbContext = ServiceProvider.GetService<ApplicationDbContext>();
            var door = dbContext.Doors.FirstOrDefault();

            await doorStatusService.CheckAndSet(door);
            var latestHistory = await doorStatusHistoryRepository.GetLatestStatus(door.GarageId, door.DoorNo);

            latestHistory.HasValue.ShouldBe(true);
        }
        [Fact]
        public async Task Should_RegisteredLatest_Status_BeSame_WithHistory()
        {
            var dbContext = ServiceProvider.GetService<ApplicationDbContext>();
            var door = dbContext.Doors.FirstOrDefault();

            var status = await doorStatusService.CheckAndSet(door);
            var latestHistory = await doorStatusHistoryRepository.GetLatestStatus(door.GarageId, door.DoorNo);

            latestHistory.Value.ShouldBe(status);
        }
        [Fact]
        public async Task ShouldNot_RegisterStatus_When_ItSameWithHistory()
        {
            var dbContext = ServiceProvider.GetService<ApplicationDbContext>();
            var door = dbContext.Doors.FirstOrDefault();

            var firstStatus = await doorStatusService.CheckAndSet(door);
            var secondStatus = await doorStatusService.CheckAndSet(door);

            var historyCount = await dbContext.DoorStatusHistories.Where(x => x.GarageId == door.GarageId && x.DoorNo == door.DoorNo).CountAsync();
            if (firstStatus == secondStatus)
            {
                historyCount.ShouldBe(1);
            }
            else
            {
                historyCount.ShouldBe(2);
            }
        }
    }
}
