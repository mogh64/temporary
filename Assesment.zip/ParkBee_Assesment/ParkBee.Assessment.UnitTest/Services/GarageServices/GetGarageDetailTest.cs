﻿using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Exceptions;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.UnitTest.Base;
using Shouldly;
using System.Threading.Tasks;
using Xunit;

namespace ParkBee.Assessment.UnitTest.Services.GarageServices
{
    public class GetGarageDetailTest : TestBase
    {
        IGarageService garageService;
        public GetGarageDetailTest()
        {
            var doorStatusService = ServiceProvider.GetService<IDoorStatusService>();
            var garagaeRepository = ServiceProvider.GetService<IGarageRepository>();
            garageService = new GarageService(doorStatusService, garagaeRepository);
        }

        [Fact]
        public async Task Should_ThrowNotFoundException_When_GarageId_IsInvalid()
        {
          
                await Should.ThrowAsync<NotFoundException>(() => garageService.GetGarageDetail(0));
          
                
        }
        [Fact]
        public async Task Should_Return_GarageById()
        {
            
                var garage = await garageService.GetGarageDetail(1);
                garage.Name.ShouldBe("Allore");
                          
        }
        [Fact]
        public async Task Should_Return_OwnerName()
        {
          
                var garage = await garageService.GetGarageDetail(1);
                garage.OwnerName.ShouldBe("joel");
          
                
        }
        [Fact]
        public async Task Should_Return_Doors()
        {
            
                var garage = await garageService.GetGarageDetail(1);
                garage.Doors.Count.ShouldBe(3);
          
                
        }
        [Fact]
        public async Task Should_GarageStatus_MatchWith_DoorsStatus()
        {
           
                bool expectedStatus = false;

                var garage = await garageService.GetGarageDetail(1);

                foreach (var door in garage.Doors)
                {
                    expectedStatus |= door.Status;
                }
                garage.Status.ShouldBe(expectedStatus);
           
           
        }
        
    }
}
