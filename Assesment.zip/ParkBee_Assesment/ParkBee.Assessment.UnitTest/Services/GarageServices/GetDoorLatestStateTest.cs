﻿using ParkBee.Assessment.UnitTest.Base;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using System.Threading.Tasks;
using ParkBee.Assessment.Domain.Exceptions;
using Shouldly;
using Xunit;

namespace ParkBee.Assessment.UnitTest.Services.GarageServices
{
    public class GetDoorLatestStateTest : TestBase
    {
        IGarageService garageService;
        public GetDoorLatestStateTest()
        {
            var doorStatusService = ServiceProvider.GetService<IDoorStatusService>();
            var garagaeRepository = ServiceProvider.GetService<IGarageRepository>();
            garageService = new GarageService(doorStatusService, garagaeRepository);
        }
        [Fact]
        public async Task Should_Return_NotFoundException_When_GarageWithInvalidDoorNo_NotExist()
        {
            await Should.ThrowAsync<NotFoundException>(() => garageService.GetDoorLatestState(1,4));
        }
        [Fact]
        public async Task Should_Return_NotFoundException_When_InvalidGarage_NotExist()
        {
            await Should.ThrowAsync<NotFoundException>(() => garageService.GetDoorLatestState(0, 1));
        }
        [Fact]
        public async Task Should_NotBeNull_When_Door_Exist()
        {
            var doorStatus = await garageService.GetDoorLatestState(1, 1);
            doorStatus.ShouldNotBeNull();
        }
        [Fact]
        public async Task Should_Return_DoorNo_When_Door_Exist()
        {
            var doorStatus = await garageService.GetDoorLatestState(1, 1);
            doorStatus.DoorNo.ShouldBe(1);
        }
    }
}
