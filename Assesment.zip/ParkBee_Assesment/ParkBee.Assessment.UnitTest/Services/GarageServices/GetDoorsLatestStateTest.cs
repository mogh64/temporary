﻿using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.UnitTest.Base;
using Shouldly;
using System.Threading.Tasks;
using Xunit;

namespace ParkBee.Assessment.UnitTest.Services.GarageServices
{
    public class GetDoorsLatestStateTest : TestBase
    {
        IGarageService garageService;
        public GetDoorsLatestStateTest()
        {
            var doorStatusService = ServiceProvider.GetService<IDoorStatusService>();
            var garagaeRepository = ServiceProvider.GetService<IGarageRepository>();
            garageService = new GarageService(doorStatusService, garagaeRepository);
        }
        [Fact]
        public async Task Should_Return_Doors()
        {
            var doorsLatestStatus = await garageService.GetDoorsLatestState(1);
            doorsLatestStatus.Doors.Count.ShouldBe(3);
        }
        [Fact]
        public async Task Should_OverallStatus_MatchWith_DoorsStatus()
        {
            bool expectedStatus = false;

            var doorsLatestStatus = await garageService.GetDoorsLatestState(1);            

            foreach (var door in doorsLatestStatus.Doors)
            {
                expectedStatus |= door.Status;
            }
            doorsLatestStatus.Status.ShouldBe(expectedStatus);
        }
        [Fact]
        public async Task Shoul_Return_Empty_When_Garage_NotExist()
        {
            var doorsLatestStatus = await garageService.GetDoorsLatestState(0);
            doorsLatestStatus.Doors.Count.ShouldBe(0);
        }
    }
}
