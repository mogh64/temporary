﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ParkBee.Assessment.Application.FactoryServices;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Application.Services;
using ParkBee.Assessment.Domain.Interfaces.IRepositories;
using ParkBee.Assessment.Domain.OptionSettings;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using ParkBee.Assessment.Infrastructure.Persistence.Repositories;
using ParkBee.Assessment.Infrastructure.Services;
using ParkBee.Assessment.UnitTest.FakeServices;
using System;
using System.Linq;

namespace ParkBee.Assessment.UnitTest.Base
{
    public class TestBase
    {
        protected IServiceProvider ServiceProvider { get; private set; }
        public TestBase()
        {
            var services = new ServiceCollection();

            AddRepositories(services);
            AddServices(services);

            services.AddDbContext<ApplicationDbContext>(options => options.UseInMemoryDatabase("parkBee"));

            AddCinfigurations(services);

            ServiceProvider = services.BuildServiceProvider();

            GenerateTestData();

        }
                
        private void GenerateTestData()
        {
            using (var scope = ServiceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                if (!context.Users.Any())
                 {
                     context.SeedTestData();
                 }                                   
            }
        }

        private  void AddCinfigurations(ServiceCollection services)
        {
            var configuration = new ConfigurationBuilder()
                            .AddJsonFile("appsettings.json")
                            .Build();

            services.AddOptions();            
            services.Configure<SettingsOptions>(configuration.GetSection(SettingsOptions.Name));
        }

        private static void AddRepositories(IServiceCollection services)
        {
            services.AddScoped<IGarageRepository, GarageRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IDoorStatusHistoryRepository, DoorStatusHistoryRepository>();
        }

        private static void AddServices(IServiceCollection services)
        {
            services.AddScoped<IDoorStatusService, DoorStatusService>();
            services.AddScoped<IPingServiceFactory, PingServiceFactory>();
            services.AddScoped<IPingService, FakePingService>();
            services.AddScoped<ICacheService, FakeCache>();
        }
    }
}
