﻿using ParkBee.Assessment.Domain.Entities;
using ParkBee.Assessment.Infrastructure.Persistence.Database;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ParkBee.Assessment.UnitTest.Base
{
    public static class DbContextExtension
    {       
        public static void SeedTestData(this ApplicationDbContext dbContext)
        {            
                        
            dbContext.Users.AddRange(
            new User()
            {
                GarageId = 1,
                Id = 1,
                UserName = "joel",
                Password = "1234",
                EMail = "joel@gmail.com"
            }
            );

            dbContext.Garages.AddRange(
            new Garage()
            {
                Id = 1,
                Address = "Fredriche Street",
                Name = "Allore",
                OwnerId = 1
            });

            dbContext.Doors.AddRange(
                    new Door() { Id = 1, GarageId = 1, DoorNo = 1, IPAddress = "142.250.179.195", Name = "First Door" },
                    new Door() { Id = 2, GarageId = 1, DoorNo = 2, IPAddress = "142.250.179.196", Name = "Second Door" },
                    new Door() { Id = 3, GarageId = 1, DoorNo = 3, IPAddress = "142.250.179.197", Name = "Third Door" }
                    );

            dbContext.SaveChanges();
        }
    }
}
