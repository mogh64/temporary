﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Common
{
    public struct CacheData<T>
    {        
        public T Data { get; set; }
        public bool HasValue { get; set; }
        public bool IsNull => !HasValue;
    }
}
