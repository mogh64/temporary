﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Common
{
    public class CurrentUser
    {
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public int GarageId { get; set; }
    }
}
