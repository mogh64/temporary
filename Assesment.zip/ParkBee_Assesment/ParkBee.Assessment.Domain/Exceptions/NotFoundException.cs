﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Exceptions
{
    public class NotFoundException:ApplicationException
    {
        public NotFoundException(string message)
            :base(message)
        {

        }
        public NotFoundException()
        {

        }
    }
}
