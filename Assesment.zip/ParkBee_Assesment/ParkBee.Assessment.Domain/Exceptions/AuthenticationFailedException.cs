﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Exceptions
{
    public class AuthenticationFailedException:ApplicationException
    {
    }
}
