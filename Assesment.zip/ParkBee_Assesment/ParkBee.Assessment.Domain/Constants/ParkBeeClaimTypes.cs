﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Constants
{
    public class ParkBeeClaimTypes
    {
        public const string GarageId = "http://schemas.parkbee.com/ws/identity/claims/garageid";
    }
}
