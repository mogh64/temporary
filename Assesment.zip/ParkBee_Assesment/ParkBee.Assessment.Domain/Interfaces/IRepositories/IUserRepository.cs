﻿using ParkBee.Assessment.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Domain.Interfaces.IRepositories
{
    public interface IUserRepository
    {
        Task<User> Login(string username, string password);
    }
}
