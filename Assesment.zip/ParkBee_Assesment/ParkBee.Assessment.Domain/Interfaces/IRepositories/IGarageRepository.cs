﻿using ParkBee.Assessment.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Domain.Interfaces.IRepositories
{
    public interface IGarageRepository
    {
        Task<Garage> GetByNavigations(int garageId);
        Task<Door> GetDoor(int garageId, int doorNo);
        Task<List<Door>> GetDoors(int garageId);
    }
}
