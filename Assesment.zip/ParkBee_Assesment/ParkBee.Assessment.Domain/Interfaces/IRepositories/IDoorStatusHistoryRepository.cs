﻿using ParkBee.Assessment.Domain.Entities;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Domain.Interfaces.IRepositories
{
    public interface IDoorStatusHistoryRepository
    {        
        Task AppendStatusHistory(DoorStatusHistory doorStatusHistory);
        Task<bool?> GetLatestStatus(int garageId, int doorNo);
    }
}
