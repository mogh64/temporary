﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.OptionSettings
{
    public class SettingsOptions
    {
        public const string Name = "Settings";
        public bool UseFakePing { get; set; } = false;
    }
}
