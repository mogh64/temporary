﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ParkBee.Assessment.Domain.Entities
{
    public class DoorStatusHistory
    {
        protected DoorStatusHistory()
        {

        }
        public DoorStatusHistory(int garageId,int doorNo,bool status)
        {
            OnlineStatus = status;
            DoorNo = doorNo;
            GarageId = garageId;
            ChangedDateTime = DateTime.Now;
        }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public bool OnlineStatus { get;private set; }
        public int DoorNo { get;private set; }
        public int GarageId { get;private set; }
        public DateTime ChangedDateTime { get;private set; }
    }
}
