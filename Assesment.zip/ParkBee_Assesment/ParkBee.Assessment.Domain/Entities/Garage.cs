﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Domain.Entities
{
    public class Garage
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int OwnerId { get; set; }
        public User Owner { get; set; }
        public IList<Door> Doors { get; set; }

    }
}
