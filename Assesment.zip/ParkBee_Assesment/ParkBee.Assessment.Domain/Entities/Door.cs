﻿namespace ParkBee.Assessment.Domain.Entities
{
    public class Door
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int GarageId { get; set; }
        public string IPAddress { get; set; }
        public int DoorNo { get; set; }
    }
}
