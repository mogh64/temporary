﻿namespace ParkBee.Assessment.Domain.Enums
{
    public enum DoorStatus
    {
        Offline = 0,
        Online
    }
}
