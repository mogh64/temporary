In backend api appsettings file,there is a config named 'UseFakePing' which it has set by default to 'true'.
The purpose of this setting is to facilitiate front tests.
In seed data I have used google IP Addresses for doors ip address,so if you set this setting to true ,It randomly generate ping result (true or false) for the specified Ip address,so you could sense this change in the UI.
But for real ping just set it false!