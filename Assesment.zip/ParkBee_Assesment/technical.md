1.What architectures or patterns are you using currently or have worked on recently?
Currently I am working with microservice architecture,ny applying some patterns and architectural styles such as : CQRS,EventSourcing,Onion & Clean Architecture and etc..I have worked with architectures such as SOA,Multi-Tiered,Monolith Modular architectures lately.

2.What do you think of them and would you want to implement it again?
It depends on the requirements of the project.In some situations even monolith& multi-tiered aproach could be beneficial,but when scalability comes to play specially when there were possiblity to grow the bussiness, microservice architecture could make great values,but it increases overall cost of  maintainability.Actually ,everything comes with a cost,so the cost & benefits of applying an specific architecture must be compromised correctly.

3.What version control system do you use or prefer?
Currently we are using Azure Devops source control with git engine.But for my personal projects I use github mostly.

4.What is your favorite language feature and can you give a short snippet on how you use it?
I try to use updated features of c# language as much as it is possible.Features such as Linq,String Interpolation,ReadOnly Auto Property,Null-conditional operators are most used features to me.But I think Linq is the most favorite one.

locationTaxes.GroupBy(x => x.userId)
                                .Select(x => new List<int>
                                               {  x.Key, Convert.ToInt32
                                                 ( x.Sum(p => p.amountValue) )})
                                .ToList();
	
5.What future or current technology do you look forward to the most or want to use and why?
It is my plan and I try to learn more about Event-Driven architecture and Reactive Systems.Beside of learning this concepts I want to learn Kafka in more detail.Becouse ,I think there are some requirements in bussiness to design more elastic , resilient and responsive systems bringing immediate response and feedbacks to the end user or system acting on when it needed.But,currently my priority is to gain deeper knowledge of DDD ,becouse I need a deeper knowledge of it in one of my projects.

6.How would you find a production bug/performance issue? Have you done this before?
I've encountered with this issues a lot.Most of the efforts are related to the predicting the behavior of system when load increases.
It is important to find bottleneks and prioritize betweeen them by their percent of impact.In some situations ,bottleneks may arise from a bussiness itseld,as we had in one of our high valuable systems.
In high cuncurrent systems ,predicting the situations could be more hard,so having a great experience to analyze the situation is a critical point.

7.How would you improve the sample API (bug fixes, security, performance, etc.)?
In sample API,I've used Caching for keeping the last updated value of door status in memory,becouse there are more possibility to remain unchanged in the status of  doors.









