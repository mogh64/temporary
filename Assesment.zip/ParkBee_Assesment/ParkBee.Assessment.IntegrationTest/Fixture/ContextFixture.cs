﻿using ParkBee.Assessment.Infrastructure.Persistence.Database;
using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.IntegrationTest.Fixture
{
    public class ContextFixture : IDisposable
    {
        public ApplicationDbContext dbContext;
        public ContextFixture()
        {
            dbContext = new ApplicationDbContext();
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        ~ContextFixture()
        {
            // Finalizer calls Dispose(false)
            Dispose(false);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // free managed resources
                if (dbContext != null)
                {
                    dbContext.Dispose();
                    dbContext = null;
                }
            }
        }
    }
}
