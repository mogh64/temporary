using System;
using Xunit;

namespace ParkBee.Assessment.IntegrationTest
{
    public class GarageControllerTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
