﻿using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Exceptions;
using System.Net.NetworkInformation;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Infrastructure.Services
{
    public class PingService : IPingService
    {
        private const int MAX_RETRY_COUNT = 2;
        private const int PING_DELAY_MILISECOND = 1000;
        public PingService()
        {

        }

        public string Type => "real";

        public Task<bool> CheckIsAvailable(string ipAddress)
        {
            return PingAddress(ipAddress);
        }

        private async Task<bool> PingAddress(string ipAddress, int retryCount = 0)
        {
            try
            {
                Ping pingSender = new Ping();
                PingReply pingresult = await pingSender.SendPingAsync(ipAddress);

                if (pingresult.Status == IPStatus.Success)
                {
                    return true;
                }
                else
                {
                    if (retryCount == MAX_RETRY_COUNT - 1)
                    {
                        return false;
                    }
                    await Task.Delay(PING_DELAY_MILISECOND);
                    return await PingAddress(ipAddress, retryCount + 1);
                }
            }
            catch
            {
                throw new NetworkConnectionException();
            }
        }
    }
}
