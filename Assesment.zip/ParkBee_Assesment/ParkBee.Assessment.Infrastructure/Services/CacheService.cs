﻿using EasyCaching.Core;
using ParkBee.Assessment.Application.Interfaces;
using ParkBee.Assessment.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace ParkBee.Assessment.Infrastructure.Services
{
    public class CacheService : ICacheService
    {
        private readonly IEasyCachingProvider provider;

        public CacheService(IEasyCachingProvider provider )
        {
            this.provider = provider;
        }
        public CacheData<T> Get<T>(string key)
        {
            var cacheValue = provider.Get<T>(key);
            return new CacheData<T>()
            {
                Data = cacheValue.Value,
                HasValue = cacheValue.HasValue
            };
        }

        public void Set<T>(string key, T value)
        {
            provider.Set<T>(key, value, TimeSpan.FromMinutes(20));
        }
    }
}
