﻿using ParkBee.Assessment.Application.Interfaces;
using System;
using System.Threading.Tasks;

namespace ParkBee.Assessment.Infrastructure.Services
{
    public class FakePingService : IPingService
    {
        public string Type => "fake";

        public Task<bool> CheckIsAvailable(string ipAddress)
        {
            if (ipAddress.Split('.').Length==4)
            {
                Random rnd = new Random();
                var randomNumber = rnd.Next(0, 10);
                return Task.FromResult(randomNumber%2==0);
            }
            return Task.FromResult(false);
        }
    }
}
